const Data = [
    {
        id: "1",
        img: 'https://img.gotit.vn/compress/brand/images/1704283768_TbZp7.png',

    },
    {
        id:"2",
        img:'https://cdn.tgdd.vn/News/Thumb/0/Thumb-V1-1200x628.jpg'
    },
    {
        id:"3",
        img:'https://img.gotit.vn/compress/brand/images/1704283768_TbZp7.png'
    },
    {
        id:"4",
        img:'https://cdn.tgdd.vn/Files/2019/04/25/1162936/dienthoai-1_800x450.jpg'
    }
]
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
//import Bai2 from './lab03/Bai2';
//import Bai1 from './lab03/Bai1';
import Bai1 from './lab04/bai1';
import { SettingsContextProvider } from './lab03/components_bai2/SettingContext';
import {AppProvider} from './lab04/Contexts/AppContext';

export default function App() {
  return (
     <AppProvider>
        <Bai1/>
     </AppProvider>
      
    
    
  );
}

